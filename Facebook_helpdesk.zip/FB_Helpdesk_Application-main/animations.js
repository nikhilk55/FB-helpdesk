function myFunction(x) {
  x.classList.toggle("change");
}
